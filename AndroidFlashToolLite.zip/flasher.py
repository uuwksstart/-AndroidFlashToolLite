import os
import subprocess

class FlashDevice:
    def __init__(self):
        self.firmware_path = ""

    def set_firmware_path(self, path):
        self.firmware_path = path

    def flash_device(self):
        if not self.firmware_path:
            return False

        try:
            files = os.listdir(self.firmware_path)
            for file in files:
                if file.endswith(".img"):
                    partition = file.replace(".img", "")
                    img_path = os.path.join(self.firmware_path, file)
                    subprocess.run(["fastboot", "flash", partition, img_path], check=True)

            subprocess.run(["fastboot", "reboot"], check=True)
            return True
        except subprocess.CalledProcessError:
            return False