from PyQt5.QtWidgets import QMainWindow, QPushButton, QLabel, QLineEdit, QVBoxLayout, QWidget

class Ui_MainWindow(QMainWindow):
    def setupUi(self, MainWindow):
        MainWindow.setWindowTitle("Android Flash Tool Lite")
        MainWindow.resize(400, 200)

        self.centralWidget = QWidget(MainWindow)
        self.setCentralWidget(self.centralWidget)

        self.layout = QVBoxLayout(self.centralWidget)

        self.firmwarePath = QLineEdit()
        self.firmwarePath.setPlaceholderText("请选择固件目录")
        self.firmwarePath.setReadOnly(True)

        self.selectButton = QPushButton("选择固件")
        self.flashButton = QPushButton("开始刷机")
        self.statusLabel = QLabel("状态：等待中")

        self.layout.addWidget(self.firmwarePath)
        self.layout.addWidget(self.selectButton)
        self.layout.addWidget(self.flashButton)
        self.layout.addWidget(self.statusLabel)