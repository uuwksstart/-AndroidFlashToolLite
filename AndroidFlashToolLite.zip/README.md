# AndroidFlashToolLite

一个简易的安卓手机刷机工具，支持 Fastboot 模式下刷写官方固件。使用 Python 和 PyQt5 构建，适合初学者和开发者。

## ✨ 功能特点

- 支持 fastboot 固件刷写
- 自动检测设备连接状态
- 简洁图形界面
- 支持跨平台（Windows/Linux/macOS）

## 🚀 安装

```bash
git clone https://github.com/你的用户名/AndroidFlashToolLite.git
cd AndroidFlashToolLite
pip install -r requirements.txt
```

## 🧩 使用方法

1. 将手机进入 Fastboot 模式并连接至电脑
2. 启动程序：
   ```bash
   python main.py
   ```
3. 选择固件目录并点击“开始刷机”

## 🛠️ 依赖库

- Python 3.7+
- PyQt5
- adb / fastboot 工具（需手动安装）

## 📄 License

本项目基于 MIT License 开源。