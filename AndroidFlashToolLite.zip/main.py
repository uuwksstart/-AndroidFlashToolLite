from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QFileDialog, QLabel, QVBoxLayout, QWidget
from ui_main import Ui_MainWindow
from flasher import FlashDevice
import sys

class FlashTool(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.flash = FlashDevice()

        self.selectButton.clicked.connect(self.select_firmware)
        self.flashButton.clicked.connect(self.start_flash)

    def select_firmware(self):
        directory = QFileDialog.getExistingDirectory(self, "选择固件目录")
        if directory:
            self.firmwarePath.setText(directory)
            self.flash.set_firmware_path(directory)

    def start_flash(self):
        self.statusLabel.setText("正在刷机...")
        result = self.flash.flash_device()
        self.statusLabel.setText("刷机完成" if result else "刷机失败")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FlashTool()
    window.show()
    sys.exit(app.exec_())